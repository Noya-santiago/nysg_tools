def hi():
    print("hiiii")
