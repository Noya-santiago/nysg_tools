# Labo-Tools 

Una colección de funciones utiles para los laboratorios de Física de la UBA.

## Install

```sh
python -m pip install labotools-nysg
```

## Usage

```py
import labotools-nysg as ny
```

## Licensing
The code in this project is licensed under MIT license.

