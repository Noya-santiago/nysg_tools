# Labo-Tools 

Una colección de funciones utiles para los laboratorios de Física de la UBA.

## Install

```sh
python -m pip install nysg_tools
```

## Usage

```py
!pip install nysg_tools
import nysg_tools as ny
```

## Licensing
The code in this project is licensed under MIT license.

